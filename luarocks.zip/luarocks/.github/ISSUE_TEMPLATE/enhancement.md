---
name: Enhancements
about: New functionality
labels: 'enhancement'

---

### Please fill out the following:
- **Description:**
  - Please describe in plain English what the enhancement is and what the use case
    is.

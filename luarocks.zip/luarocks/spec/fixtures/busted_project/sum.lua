local sum = {}

function sum.sum(a, b)
   return a + b
end

return sum
